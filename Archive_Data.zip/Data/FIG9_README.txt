Figure 9 — Schematic of Multiscale Biophysical Interactions (data-driven)

FILES
- fig9_schematic_code.py
  Renders the schematic from a JSON scene description using matplotlib.

- figure9_schematic_scene.json
  Scene graph describing nodes (modules) and arrows (interactions), including labels and positions.

RUN
    python fig9_schematic_code.py

OUTPUT
- figure9_schematic.png (300 dpi)
