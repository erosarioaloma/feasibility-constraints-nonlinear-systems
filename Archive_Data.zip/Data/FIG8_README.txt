Figure 7 (Biophysics paper) — Code + Data

FILES
- fig7_code.py
    Regenerates Figure 7-style panels from the CSVs and writes figure7.png

- figure7_timeseries.csv
    Tidy time-series for each burden level:
    columns: time_h, burden, bacteria_B, pH, tumor_T_norm, effector_Tcells_E_norm

- figure7_summary.csv
    One row per burden level with summary metrics:
    TT90_h (time to 90% tumor reduction), pH_max, immune_rescue_auc

RUN
    python fig7_code.py
