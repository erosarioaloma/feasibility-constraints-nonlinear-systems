Figure 7 — Combined Feasibility Map (Master Phase Diagram)

FILES
- fig7_phase_code.py
  Reads the CSVs and generates the phase diagram PNG (with Xi=1, Lambda=1, Psi=1 overlays).

- figure7_phase_diagram_data.csv
  Full 2D sweep (one row per (R, kUG*)) with computed Xi, Lambda, Psi and a discrete outcome label.

- figure7_phase_diagram_boundaries.csv
  Convenience boundary curves for Lambda=1, Psi=1, Xi=1, parameterized by R.

NOTES
- R and kUG_star are dimensionless scales (can be interpreted as normalized tumor radius and effective
  neutralization strength). Xi, Lambda, Psi are dimensionless control parameters.
- Outcome logic:
    full_clearance: Xi>1 AND Lambda<1 AND Psi<1
    partial_control: approximately 2/3 conditions satisfied OR near feasibility boundaries
    failure: otherwise

RUN
    python fig7_phase_code.py
