import numpy as np
import matplotlib.pyplot as plt

def load_phase_map(path="fig6A_phase_map.csv"):
    data = np.loadtxt(path, delimiter=",", skiprows=1)
    k_eff = data[:, 0]
    D = data[:, 1]
    Lambda = data[:, 2]
    regime = data[:, 3]
    return k_eff, D, Lambda, regime

def load_promoter_map(path="fig6B_promoter_sharpness.csv"):
    data = np.loadtxt(path, delimiter=",", skiprows=1)
    Ka = data[:, 0]
    n_a = data[:, 1]
    delta_a = data[:, 2]
    return Ka, n_a, delta_a

def load_activation_map(path="fig6C_activation_map.csv"):
    data = np.loadtxt(path, delimiter=",", skiprows=1)
    x = data[:, 0]
    y = data[:, 1]
    a_mid = data[:, 2]
    u_activation = data[:, 3]
    return x, y, a_mid, u_activation

def main():
    # --- Panel A: Phase map in (k_eff, D) space ---
    k_eff, D, Lambda, regime = load_phase_map()
    # Reconstruct grid shape
    nD = len(np.unique(D))
    nk = len(np.unique(k_eff))
    K = k_eff.reshape(nD, nk)
    DD = D.reshape(nD, nk)
    Regime = regime.reshape(nD, nk)

    # --- Panel B: Promoter sharpness map ---
    Ka, n_a, delta_a = load_promoter_map()
    nn = len(np.unique(n_a))
    nK = len(np.unique(Ka))
    KAG = Ka.reshape(nn, nK)
    nAG = n_a.reshape(nn, nK)
    DeltaA = delta_a.reshape(nn, nK)

    # --- Panel C: Spatial activation map ---
    x, y, a_mid, u_activation = load_activation_map()
    N = int(np.sqrt(x.size))
    X = x.reshape(N, N)
    Y = y.reshape(N, N)
    U = u_activation.reshape(N, N)

    fig, axes = plt.subplots(1, 3, figsize=(15, 4))

    # Panel A: Regime map
    im0 = axes[0].imshow(
        Regime,
        origin="lower",
        extent=[K.min(), K.max(), DD.min(), DD.max()],
        aspect="auto"
    )
    axes[0].set_xlabel(r"Neutralization strength $k_{\mathrm{eff}}$")
    axes[0].set_ylabel(r"Diffusion coefficient $D$")
    axes[0].set_title("A. Neutralization–diffusion regimes")
    cbar0 = fig.colorbar(im0, ax=axes[0], fraction=0.046, pad=0.04)
    cbar0.set_label("Regime code (0: reaction, 1: balanced, 2: diffusion)")

    # Panel B: Promoter sharpness (Δa)
    im1 = axes[1].imshow(
        DeltaA,
        origin="lower",
        extent=[KAG.min(), KAG.max(), nAG.min(), nAG.max()],
        aspect="auto"
    )
    axes[1].set_xlabel(r"Promoter threshold $K_a$")
    axes[1].set_ylabel(r"Hill coefficient $n_a$")
    axes[1].set_title(r"B. Promoter sharpness $\Delta a$")
    cbar1 = fig.colorbar(im1, ax=axes[1], fraction=0.046, pad=0.04)
    cbar1.set_label(r"Width $\Delta a$ ($u=0.1 \to 0.9$)")

    # Panel C: Spatial activation map
    im2 = axes[2].imshow(
        U,
        origin="lower",
        extent=[X.min(), X.max(), Y.min(), Y.max()],
        aspect="equal"
    )
    axes[2].set_xlabel("x (normalized)")
    axes[2].set_ylabel("y (normalized)")
    axes[2].set_title("C. Spatial promoter activation")
    cbar2 = fig.colorbar(im2, ax=axes[2], fraction=0.046, pad=0.04)
    cbar2.set_label(r"Activation $u(a)$")

    plt.tight_layout()
    plt.savefig("fig6_phase_promoter_activation.png", dpi=300)
    plt.close()

if __name__ == "__main__":
    main()
