import numpy as np
import matplotlib.pyplot as plt

def main():
    # Load precomputed steady-state profiles
    data = np.loadtxt("fig4_acidity_profiles.csv", delimiter=",", skiprows=1)
    x = data[:, 0]
    a_weak = data[:, 1]
    a_intermediate = data[:, 2]
    a_strong = data[:, 3]

    plt.figure(figsize=(6, 4))
    plt.plot(x, a_weak, label="Weak neutralization")
    plt.plot(x, a_intermediate, label="Intermediate neutralization")
    plt.plot(x, a_strong, label="Strong neutralization")

    plt.xlabel("Position x (normalized tumor radius)")
    plt.ylabel("Steady-state acidity proxy a*(x)")
    plt.title("1D Steady-State Acidity Profiles Across Tumor Radius")
    plt.legend(loc="best")
    plt.tight_layout()
    plt.savefig("fig4_acidity_profiles.png", dpi=300)
    plt.close()

if __name__ == "__main__":
    main()
