import numpy as np
import matplotlib.pyplot as plt

def u(a, Ka, na):
    """Acidity-responsive promoter activation."""
    return a**na / (Ka**na + a**na)

def main():
    Ka = 0.5
    na_values = [1, 2, 4, 8]
    a = np.linspace(0, 1.5, 500)

    # Compute curves
    u_curves = [u(a, Ka, na) for na in na_values]

    # Save data
    data = np.column_stack([a] + u_curves)
    header = "a,u_n1,u_n2,u_n4,u_n8"
    np.savetxt("fig2_promoter_data.csv", data, delimiter=",", header=header, comments="")

    # Plot Figure 2
    plt.figure(figsize=(5, 4))
    for curve, na in zip(u_curves, na_values):
        plt.plot(a, curve, label=f"n_a = {na}")

    plt.axvline(Ka, linestyle="--")
    plt.xlabel("Acidity proxy a")
    plt.ylabel("Promoter activation u(a)")
    plt.title("Acidity-responsive promoter activation")
    plt.legend(loc="best")
    plt.tight_layout()
    plt.savefig("fig2_promoter_curves.png", dpi=300)
    plt.close()

if __name__ == "__main__":
    main()
