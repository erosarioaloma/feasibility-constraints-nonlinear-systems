
import numpy as np
import matplotlib.pyplot as plt

def main():
    # Load data
    data = np.loadtxt("fig3_bifurcation_data.csv", delimiter=",", skiprows=1)
    Ka = data[:,0]
    T_stable = data[:,1]
    T_unstable = data[:,2]

    plt.figure(figsize=(6,4))
    plt.plot(Ka, T_stable, "b-", label="Stable equilibria")
    plt.plot(Ka, T_unstable, "r--", label="Unstable equilibria")

    plt.xlabel("Promoter threshold $K_a$")
    plt.ylabel("Steady-state tumor density $T^*$")
    plt.title("Bifurcation Diagram of Tumor Steady States")
    plt.legend()
    plt.tight_layout()
    plt.savefig("fig3_bifurcation_diagram.png", dpi=300)
    plt.close()

if __name__ == "__main__":
    main()
