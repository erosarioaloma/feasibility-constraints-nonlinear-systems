"""
Figure 7 — Metabolic burden / resource allocation tradeoffs

This script regenerates Figure 7-style plots from the provided CSV data files:
- figure7_timeseries.csv
- figure7_summary.csv

Usage:
    python fig7_code.py

Outputs:
    figure7.png
"""

from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent

def main():
    ts = pd.read_csv(HERE / "figure7_timeseries.csv")
    summ = pd.read_csv(HERE / "figure7_summary.csv")

    # Consistent ordering by burden
    burdens = sorted(ts["burden"].unique())

    # Pick a subset of burdens to avoid clutter in time-series panels
    show = [burdens[0], burdens[len(burdens)//2], burdens[-1]]

    fig = plt.figure(figsize=(12, 8))

    # Panel A: pH(t)
    ax1 = fig.add_subplot(2, 2, 1)
    for b in show:
        d = ts[ts["burden"] == b]
        ax1.plot(d["time_h"], d["pH"], label=f"burden={b:.2f}")
    ax1.set_xlabel("Time (h)")
    ax1.set_ylabel("pH")
    ax1.set_title("A. pH normalization vs metabolic burden")
    ax1.legend(frameon=False)

    # Panel B: Tumor dynamics
    ax2 = fig.add_subplot(2, 2, 2)
    for b in show:
        d = ts[ts["burden"] == b]
        ax2.plot(d["time_h"], d["tumor_T_norm"], label=f"burden={b:.2f}")
    ax2.set_xlabel("Time (h)")
    ax2.set_ylabel("Tumor density (T/T0)")
    ax2.set_title("B. Tumor suppression degrades with higher burden")
    ax2.legend(frameon=False)

    # Panel C: Effector T-cell rescue
    ax3 = fig.add_subplot(2, 2, 3)
    for b in show:
        d = ts[ts["burden"] == b]
        ax3.plot(d["time_h"], d["effector_Tcells_E_norm"], label=f"burden={b:.2f}")
    ax3.set_xlabel("Time (h)")
    ax3.set_ylabel("Effector T cells (E/E0)")
    ax3.set_title("C. Immune rescue vs burden")
    ax3.legend(frameon=False)

    # Panel D: Tradeoff curves (summary metrics)
    ax4 = fig.add_subplot(2, 2, 4)
    ax4.plot(summ["burden"], summ["pH_max"], marker="o", label="max pH")
    ax4.plot(summ["burden"], summ["immune_rescue_auc"], marker="s", label="immune rescue (AUC)")
    # TT90 may be NaN for some burdens; plot only finite
    finite = np.isfinite(summ["TT90_h"].values)
    if finite.any():
        ax4.plot(summ.loc[finite, "burden"], summ.loc[finite, "TT90_h"], marker="^", label="TT90 (h)")
    ax4.set_xlabel("Metabolic burden (fractional cost)")
    ax4.set_title("D. Burden–efficacy tradeoffs")
    ax4.legend(frameon=False)

    fig.tight_layout()
    out = HERE / "figure7.png"
    fig.savefig(out, dpi=300, bbox_inches="tight")
    print(f"Saved: {out}")

if __name__ == "__main__":
    main()
