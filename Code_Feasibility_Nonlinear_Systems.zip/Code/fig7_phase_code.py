"""
Figure 7 — Combined Feasibility Map (Master Phase Diagram)

Generates a discrete outcome phase diagram in (k_U G*, R) space and overlays
the feasibility boundaries Xi=1, Lambda=1, Psi=1.

Inputs:
    - figure7_phase_diagram_data.csv
    - figure7_phase_diagram_boundaries.csv

Outputs:
    - figure7_phase_diagram.png (300 dpi)

Run:
    python fig7_phase_code.py
"""

from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent

def main():
    df = pd.read_csv(HERE / "figure7_phase_diagram_data.csv")
    bd = pd.read_csv(HERE / "figure7_phase_diagram_boundaries.csv")

    # Pivot to grid
    # Rows: kUG_star, Cols: R
    Rs = np.sort(df["R"].unique())
    Ks = np.sort(df["kUG_star"].unique())

    # Map outcomes to integers for plotting (0=failure, 1=partial, 2=full)
    mapping = {"failure": 0, "partial_control": 1, "full_clearance": 2}
    df["outcome_code"] = df["outcome"].map(mapping).astype(int)

    Z = df.pivot(index="kUG_star", columns="R", values="outcome_code").values

    fig = plt.figure(figsize=(10, 7))
    ax = fig.add_subplot(1, 1, 1)

    # Use pcolormesh on log scales (discrete)
    # Note: we provide edges by extending with geometric means
    R_edges = np.concatenate(([Rs[0] / np.sqrt(Rs[1]/Rs[0])],
                              np.sqrt(Rs[:-1] * Rs[1:]),
                              [Rs[-1] * np.sqrt(Rs[-1]/Rs[-2])]))
    K_edges = np.concatenate(([Ks[0] / np.sqrt(Ks[1]/Ks[0])],
                              np.sqrt(Ks[:-1] * Ks[1:]),
                              [Ks[-1] * np.sqrt(Ks[-1]/Ks[-2])]))

    mesh = ax.pcolormesh(R_edges, K_edges, Z, shading="auto")

    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("Tumor scale, R")
    ax.set_ylabel("Effective neutralization strength, $k_U G^*$")
    ax.set_title("Figure 7. Combined Feasibility Map (Master Phase Diagram)")

    # Overlay feasibility boundaries
    ax.plot(bd["R"], bd["kUG_star_Lambda_eq_1"], linestyle="--", label=r"$\Lambda=1$")
    ax.plot(bd["R"], bd["kUG_star_Psi_eq_1"], linestyle=":", label=r"$\Psi=1$")
    # Xi boundary may have NaNs where not solvable
    ax.plot(bd["R"], bd["kUG_star_Xi_eq_1"], linestyle="-.", label=r"$\Xi=1$")

    ax.legend(frameon=False, loc="lower left")

    # Provide a compact legend for discrete regions (as text)
    ax.text(0.02, 0.98,
            "Outcome codes:\n0 = failure (red)\n1 = partial control (yellow)\n2 = full clearance (green)",
            transform=ax.transAxes, va="top")

    fig.tight_layout()
    out = HERE / "figure7_phase_diagram.png"
    fig.savefig(out, dpi=300, bbox_inches="tight")
    print(f"Saved: {out}")

if __name__ == "__main__":
    main()
