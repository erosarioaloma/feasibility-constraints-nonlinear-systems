import numpy as np
import matplotlib.pyplot as plt

def main():
    # Load 2D acidity maps
    data = np.loadtxt("fig5_acidity_heatmaps.csv", delimiter=",", skiprows=1)
    x = data[:, 0]
    y = data[:, 1]
    a_weak = data[:, 2]
    a_intermediate = data[:, 3]
    a_strong = data[:, 4]

    # Determine grid size
    N = int(np.sqrt(x.size))
    X = x.reshape(N, N)
    Y = y.reshape(N, N)
    A_weak = a_weak.reshape(N, N)
    A_inter = a_intermediate.reshape(N, N)
    A_strong = a_strong.reshape(N, N)

    fig, axes = plt.subplots(1, 3, figsize=(12, 4), sharex=True, sharey=True)

    im0 = axes[0].imshow(A_weak, origin="lower",
                         extent=[X.min(), X.max(), Y.min(), Y.max()],
                         aspect="equal")
    axes[0].set_title("Weak neutralization")
    axes[0].set_xlabel("x")
    axes[0].set_ylabel("y")
    fig.colorbar(im0, ax=axes[0], fraction=0.046, pad=0.04)

    im1 = axes[1].imshow(A_inter, origin="lower",
                         extent=[X.min(), X.max(), Y.min(), Y.max()],
                         aspect="equal")
    axes[1].set_title("Intermediate neutralization")
    axes[1].set_xlabel("x")
    fig.colorbar(im1, ax=axes[1], fraction=0.046, pad=0.04)

    im2 = axes[2].imshow(A_strong, origin="lower",
                         extent=[X.min(), X.max(), Y.min(), Y.max()],
                         aspect="equal")
    axes[2].set_title("Strong neutralization")
    axes[2].set_xlabel("x")
    fig.colorbar(im2, ax=axes[2], fraction=0.046, pad=0.04)

    plt.tight_layout()
    plt.savefig("fig5_acidity_heatmaps.png", dpi=300)
    plt.close()

if __name__ == "__main__":
    main()
