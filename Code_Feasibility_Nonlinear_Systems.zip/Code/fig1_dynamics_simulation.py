import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

def S(a, a50=0.4, m=3):
    """Acidity-dependent immune suppression."""
    return a**m / (a50**m + a**m)

def u(a, Ka, na):
    """Acidity-responsive promoter activation."""
    return a**na / (Ka**na + a**na)

def make_rhs(params, Ka, na):
    """Build the ODE right-hand side for given parameters."""
    rT, KT, kE, kG, sE, dE, pG, dG, qT, kU = params

    def rhs(t, y):
        T, E, G, a = y
        dTdt = rT * T * (1 - T / KT) - kE * T * E - kG * T * G
        dEdt = sE - (dE + S(a)) * E
        dGdt = pG * u(a, Ka, na) - dG * G
        dadt = qT * T - kU * G * a
        return [dTdt, dEdt, dGdt, dadt]

    return rhs

def simulate_trajectory(params, Ka, na, y0, t_span=(0, 400), n_points=2000):
    """Integrate the system and return time + solution."""
    rhs = make_rhs(params, Ka, na)
    t_eval = np.linspace(t_span[0], t_span[1], n_points)
    sol = solve_ivp(rhs, t_span, y0, t_eval=t_eval,
                    rtol=1e-7, atol=1e-9)
    return sol.t, sol.y

def main():
    Ka = 0.5  # promoter half-activation

    # Failure (tumor persists)
    params_fail = [0.05, 1.0, 0.2, 0.05, 0.02, 0.02, 0.03, 0.05, 0.08, 0.4]
    na_fail = 2
    y0_fail = [0.2, 0.1, 0.0, 0.5]

    # Clearance (tumor eliminated)
    params_clear = [0.05, 1.0, 0.3, 0.2, 0.05, 0.02, 0.25, 0.05, 0.08, 0.6]
    na_clear = 2
    y0_clear = [0.2, 0.1, 0.0, 0.5]

    # Bistable regime
    params_bistable = [0.05, 1.0, 0.2, 0.15, 0.03, 0.02, 0.12, 0.05, 0.08, 0.4]
    na_bistable = 6
    y0_bi_A = [0.2, 0.05, 0.0, 0.7]  # trajectory leading to clearance
    y0_bi_B = [0.2, 0.3, 0.1, 0.4]   # trajectory leading to persistence

    # Simulate all trajectories
    t_fail, y_fail = simulate_trajectory(params_fail, Ka, na_fail, y0_fail)
    t_clear, y_clear = simulate_trajectory(params_clear, Ka, na_clear, y0_clear)
    t_biA, y_biA = simulate_trajectory(params_bistable, Ka, na_bistable, y0_bi_A)
    t_biB, y_biB = simulate_trajectory(params_bistable, Ka, na_bistable, y0_bi_B)

    # Save data to CSV
    t = t_fail  # all share same time grid
    data = np.column_stack([
        t,
        y_fail[0], y_clear[0], y_biA[0], y_biB[0],
        y_fail[3], y_clear[3], y_biA[3], y_biB[3]
    ])
    header = "t,T_fail,T_clear,T_biA,T_biB,a_fail,a_clear,a_biA,a_biB"
    np.savetxt("fig1_dynamics_data.csv", data, delimiter=",", header=header, comments="")

    # Plot Figure 1
    fig, axes = plt.subplots(1, 2, figsize=(10, 4), sharex=True)

    # Tumor trajectories
    axT = axes[0]
    axT.plot(t_fail,  y_fail[0],  label="Failure (persisting tumor)")
    axT.plot(t_clear, y_clear[0], label="Clearance")
    axT.plot(t_biA,   y_biA[0],   label="Bistable A (→ clearance)")
    axT.plot(t_biB,   y_biB[0],   label="Bistable B (→ persistence)")
    axT.set_xlabel("Time (a.u.)")
    axT.set_ylabel("Tumor density T(t)")
    axT.set_title("Tumor dynamics")
    axT.legend(loc="best")

    # Acidity trajectories
    axA = axes[1]
    axA.plot(t_fail,  y_fail[3],  label="Failure")
    axA.plot(t_clear, y_clear[3], label="Clearance")
    axA.plot(t_biA,   y_biA[3],   label="Bistable A")
    axA.plot(t_biB,   y_biB[3],   label="Bistable B")
    axA.set_xlabel("Time (a.u.)")
    axA.set_ylabel("Acidity proxy a(t)")
    axA.set_title("Acidity dynamics")
    axA.legend(loc="best")

    plt.tight_layout()
    plt.savefig("fig1_dynamics.png", dpi=300)
    plt.close()

if __name__ == "__main__":
    main()
