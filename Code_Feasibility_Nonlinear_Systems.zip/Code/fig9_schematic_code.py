"""
Figure 9 — Schematic of Multiscale Biophysical Interactions

This script renders a publication-ready schematic from a JSON scene description.

Inputs:
    figure9_schematic_scene.json

Outputs:
    figure9_schematic.png (300 dpi)

Run:
    python fig9_schematic_code.py
"""

from pathlib import Path
import json
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, FancyArrowPatch

HERE = Path(__file__).resolve().parent

def _center(node):
    if node["type"] == "circle":
        return np.array(node["xy"], dtype=float)
    if node["type"] == "box":
        x, y = node["xy"]
        w, h = node["wh"]
        return np.array([x + w/2, y + h/2], dtype=float)
    raise ValueError("Unknown node type")

def _bbox(node):
    if node["type"] == "circle":
        x, y = node["xy"]; r = node["r"]
        return (x-r, y-r, 2*r, 2*r)
    x, y = node["xy"]; w, h = node["wh"]
    return (x, y, w, h)

def _draw_node(ax, node, style):
    fs = style.get("font_size", 10)
    ss = style.get("subtitle_size", 8)

    if node["type"] == "circle":
        x, y = node["xy"]; r = node["r"]
        ax.add_patch(Circle((x, y), r, fill=False, linewidth=1.5))
        ax.text(x, y+0.012, node.get("label",""), ha="center", va="center", fontsize=fs)
        if node.get("subtitle"):
            ax.text(x, y-0.040, node["subtitle"], ha="center", va="center", fontsize=ss)
        return

    # box
    x, y = node["xy"]; w, h = node["wh"]
    ax.add_patch(Rectangle((x, y), w, h, fill=False, linewidth=1.5))
    cx, cy = x+w/2, y+h/2
    ax.text(cx, cy+0.020, node.get("label",""), ha="center", va="center", fontsize=fs)
    if node.get("subtitle"):
        ax.text(cx, cy-0.045, node["subtitle"], ha="center", va="center", fontsize=ss)

def _shrink_point(p_from, p_to, node_from, node_to, pad):
    """
    Move endpoints slightly away from node centers so arrows don't overlap shapes.
    """
    v = p_to - p_from
    d = np.linalg.norm(v)
    if d < 1e-9:
        return p_from, p_to
    u = v / d

    def shrink(p, node, sign):
        # sign=+1 moves forward, sign=-1 moves backward along u
        if node["type"] == "circle":
            r = node["r"] + pad
            return p + sign*u*r
        x, y, w, h = _bbox(node)
        # approximate by shrinking by min half-dimension
        r = min(w, h)/2 + pad
        return p + sign*u*r

    p1 = shrink(p_from, node_from, +1)
    p2 = shrink(p_to, node_to, -1)
    return p1, p2

def _draw_arrow(ax, nodes_by_id, arrow, style):
    pad = style.get("box_pad", 0.015)
    aw = style.get("arrow_width", 1.6)
    ah = style.get("arrow_head", 8)

    n1 = nodes_by_id[arrow["from"]]
    n2 = nodes_by_id[arrow["to"]]
    p1 = _center(n1)
    p2 = _center(n2)
    p1, p2 = _shrink_point(p1, p2, n1, n2, pad)

    curve = float(arrow.get("curve", 0.0))
    con = f"arc3,rad={curve}"

    patch = FancyArrowPatch(
        p1, p2,
        arrowstyle=f"-|>,head_length={ah},head_width={ah*0.6}",
        connectionstyle=con,
        linewidth=aw,
        mutation_scale=1.0
    )
    ax.add_patch(patch)

    label = arrow.get("label")
    if label:
        mid = (p1 + p2) / 2
        # offset label slightly perpendicular to arrow direction
        v = p2 - p1
        if np.linalg.norm(v) > 1e-9:
            perp = np.array([-v[1], v[0]])
            perp = perp / np.linalg.norm(perp)
        else:
            perp = np.array([0,1])
        mid = mid + perp * (0.02 + 0.02*abs(curve))
        ax.text(mid[0], mid[1], label, fontsize=8, ha="center", va="center")

def main():
    scene = json.loads((HERE / "figure9_schematic_scene.json").read_text(encoding="utf-8"))
    style = scene.get("style", {})

    fig = plt.figure(figsize=(12, 6))
    ax = fig.add_subplot(1, 1, 1)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")

    ax.text(0.5, 0.98, scene.get("title","Figure 9"), ha="center", va="top", fontsize=12)

    nodes = scene["nodes"]
    nodes_by_id = {n["id"]: n for n in nodes}

    # Draw nodes first
    for n in nodes:
        _draw_node(ax, n, style)

    # Then arrows (so they appear on top)
    for a in scene["arrows"]:
        _draw_arrow(ax, nodes_by_id, a, style)

    fig.tight_layout()
    out = HERE / "figure9_schematic.png"
    fig.savefig(out, dpi=300, bbox_inches="tight")
    print(f"Saved: {out}")

if __name__ == "__main__":
    main()
